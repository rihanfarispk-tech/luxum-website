const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const USER = process.env.ADMIN_USER || 'rihan';
const PASS = process.env.ADMIN_PASSWORD || 'rfluxum123';
const sessions = new Map();
const attempts = new Map();
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.mp4':'video/mp4','.md':'text/markdown; charset=utf-8','.json':'application/json'};
function send(res,status,body,type='application/json; charset=utf-8'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self' https: data:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; media-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"});res.end(body);}
function json(res,status,obj){send(res,status,JSON.stringify(obj));}
function readBody(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>3_000_000)req.destroy();});req.on('end',()=>{try{resolve(JSON.parse(b||'{}'));}catch(e){reject(e);}});});}
function session(req){const m=(req.headers.cookie||'').match(/luxum_session=([a-f0-9]+)/);if(!m || !sessions.has(m[1])) return null; const created=sessions.get(m[1]); if(Date.now()-created>8*60*60*1000){sessions.delete(m[1]);return null;} return m[1];}
function authed(req){return !!session(req);}
function safeFile(name){return ['index.html','styles.css','script.js'].includes(name);}
const adminPage = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LUXUM Admin</title><style>
*{box-sizing:border-box}body{margin:0;background:#08080d;color:#f5f3fa;font:14px Manrope,Arial,sans-serif}main{width:min(1100px,calc(100% - 32px));margin:48px auto}.panel{background:#111118;border:1px solid #30283c;padding:24px;margin:18px 0;border-radius:12px}h1{letter-spacing:-.06em;font-size:36px;margin:0 0 8px}h2{font-size:18px}.muted{color:#aaa3b4}label{display:block;color:#c7bdd4;margin:14px 0 7px}input,textarea{width:100%;background:#09090f;border:1px solid #40364f;color:#fff;padding:12px;border-radius:6px;font:13px ui-monospace,monospace}textarea{min-height:380px;resize:vertical;line-height:1.5}button{background:#a77aff;color:#09080e;border:0;padding:12px 18px;border-radius:5px;font-weight:700;cursor:pointer;margin:10px 8px 0 0}button.secondary{background:#272130;color:#eee}.row{display:flex;gap:10px;flex-wrap:wrap}.row>*{flex:1}.hidden{display:none}.status{min-height:22px;color:#c2a7ff}.tabs{display:flex;gap:8px;flex-wrap:wrap}.tabs button.active{background:#fff;color:#111}.hint{font-size:12px;color:#92899d;line-height:1.6}.danger{color:#ffb3b3}a{color:#c2a7ff}
</style></head><body><main><h1>LUXUM <span style="color:#a77aff">/</span> ADMIN</h1><p class="muted">Manage website content, offers, contact details and page assets.</p>
<section id="login" class="panel"><h2>Administrator sign in</h2><form id="loginForm"><label>Username</label><input name="username" autocomplete="username" required><label>Password</label><input name="password" type="password" autocomplete="current-password" required><button>Sign in</button></form><p id="loginStatus" class="status"></p></section>
<section id="dashboard" class="hidden"><div class="panel"><div class="row"><div><h2>Website editor</h2><p class="hint">Edit the complete HTML, CSS and JavaScript source. This gives you control over every visible section, product/offer detail, price, and page element.</p></div><div style="text-align:right"><button class="secondary" id="logout">Log out</button><p><a href="/" target="_blank">View website ↗</a></p></div></div>
<div class="tabs"><button class="active" data-file="index.html">HTML / all content</button><button class="secondary" data-file="styles.css">CSS / design</button><button class="secondary" data-file="script.js">JavaScript / behaviour</button></div>
<label id="fileLabel">index.html</label><textarea id="source" spellcheck="false"></textarea><div class="row"><button id="saveSource">Save website changes</button><button class="secondary" id="reloadSource">Discard local edits</button></div><p class="hint">HTML includes product and package names, descriptions, prices, page text and links. CSS controls the entire design. Save after editing.</p></div>
<div class="panel"><h2>Contact / WhatsApp number</h2><label>WhatsApp number (digits only, include country code)</label><input id="phone" inputmode="numeric" placeholder="919XXXXXXXXX"><button id="savePhone">Save phone number</button><p class="hint">Updates the contact form destination used by the website.</p></div>
<p id="status" class="status" role="status"></p></section></main>
<script>
const $=s=>document.querySelector(s);let current='index.html',files={};
async function api(url,opts={}){const r=await fetch(url,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Request failed');return d}
function showDash(){ $('#login').classList.add('hidden');$('#dashboard').classList.remove('hidden');load();}
async function load(){try{const d=await api('/api/admin/content');files=d.files;current='index.html';paint();$('#phone').value=d.phone||'';}catch(e){$('#status').textContent=e.message;}}
function paint(){ $('#source').value=files[current]||'';$('#fileLabel').textContent=current;document.querySelectorAll('[data-file]').forEach(b=>{b.classList.toggle('active',b.dataset.file===current);b.classList.toggle('secondary',b.dataset.file!==current);});}
document.querySelectorAll('[data-file]').forEach(b=>b.onclick=()=>{files[current]=$('#source').value;current=b.dataset.file;paint();});
$('#loginForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/admin/login',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});$('#loginStatus').textContent='';showDash();}catch(err){$('#loginStatus').textContent=err.message;}};
$('#saveSource').onclick=async()=>{files[current]=$('#source').value;try{await api('/api/admin/content',{method:'PUT',body:JSON.stringify({files})});$('#status').textContent='Saved '+current+'. Refresh the website to see changes.';}catch(e){$('#status').textContent=e.message;}};
$('#reloadSource').onclick=load;
$('#savePhone').onclick=async()=>{try{await api('/api/admin/phone',{method:'PUT',body:JSON.stringify({phone:$('#phone').value})});$('#status').textContent='WhatsApp number saved.';}catch(e){$('#status').textContent=e.message;}};
$('#logout').onclick=async()=>{await api('/api/admin/logout',{method:'POST'});location.reload();};
(async()=>{try{await api('/api/admin/content');showDash();}catch(e){}})();
</script></body></html>`;
http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/admin'){return send(res,200,adminPage,'text/html; charset=utf-8');}
  if(url.pathname==='/api/admin/login'&&req.method==='POST'){
    try{const ip=req.socket.remoteAddress||'unknown', now=Date.now(), arr=(attempts.get(ip)||[]).filter(t=>now-t<600000);if(arr.length>=8)return json(res,429,{error:'Too many attempts. Try again in 10 minutes.'});
      const b=await readBody(req);if(b.username!==USER||b.password!==PASS){arr.push(now);attempts.set(ip,arr);return json(res,401,{error:'Invalid username or password.'});}
      const token=crypto.randomBytes(32).toString('hex');sessions.set(token,now);res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':`luxum_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`,'Cache-Control':'no-store'});return res.end(JSON.stringify({ok:true}));
    }catch(e){return json(res,400,{error:'Invalid request'});}
  }
  if(url.pathname.startsWith('/api/admin/')){
    if(!authed(req))return json(res,401,{error:'Please sign in.'});
    if(url.pathname==='/api/admin/logout'&&req.method==='POST'){sessions.delete(session(req));res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':'luxum_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return res.end('{"ok":true}');}
    if(url.pathname==='/api/admin/content'&&req.method==='GET'){const files={};for(const f of ['index.html','styles.css','script.js'])files[f]=fs.readFileSync(path.join(ROOT,f),'utf8');const js=files['script.js'];const m=js.match(/const WHATSAPP_NUMBER = '([^']*)'/);return json(res,200,{files,phone:m?m[1]:''});}
    if(url.pathname==='/api/admin/content'&&req.method==='PUT'){try{const b=await readBody(req);for(const f of ['index.html','styles.css','script.js'])if(typeof b.files?.[f]==='string'&&b.files[f].length<2_000_000)fs.writeFileSync(path.join(ROOT,f),b.files[f]);return json(res,200,{ok:true});}catch(e){return json(res,400,{error:'Could not save files.'});}}
    if(url.pathname==='/api/admin/phone'&&req.method==='PUT'){try{const b=await readBody(req),phone=String(b.phone||'').replace(/\D/g,'');if(!/^\d{10,15}$/.test(phone))return json(res,400,{error:'Enter 10–15 digits including country code.'});const f=path.join(ROOT,'script.js');let s=fs.readFileSync(f,'utf8');s=s.replace(/const WHATSAPP_NUMBER = '[^']*'/,`const WHATSAPP_NUMBER = '${phone}'`);fs.writeFileSync(f,s);return json(res,200,{ok:true});}catch(e){return json(res,400,{error:'Could not save number.'});}}
    return json(res,404,{error:'Not found'});
  }
  let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';const file=path.resolve(ROOT,'.'+pathname);if(!file.startsWith(ROOT+path.sep))return send(res,403,'Forbidden','text/plain');
  fs.readFile(file,(err,data)=>{if(err)return send(res,404,'Not found','text/plain');send(res,200,data,mime[path.extname(file)]||'application/octet-stream');});
}).listen(PORT,()=>console.log(`LUXUM running at http://localhost:${PORT}`));